import os
import csv

# =========================================
# Read SCF energy from final.ener (pattern: "mol<base_name>.xyz.out")
# =========================================
def get_energy(infile, final_ener_file="final.ener"):
    base_name = os.path.basename(os.path.dirname(infile))
    search_pattern = f"mol{base_name}.xyz.out"

    if not os.path.exists(final_ener_file):
        print(f"⚠️ Warning: {final_ener_file} not found!")
        return None

    with open(final_ener_file, 'r') as f:
        for line in f:
            if search_pattern in line:
                parts = line.strip().split()
                try:
                    energy = float(parts[-1])
                    return energy
                except ValueError:
                    continue

    print(f"⚠️ Energy not found for pattern {search_pattern} in {final_ener_file}")
    return None


# =========================================
# Read thermal Gibbs correction from input.log
# =========================================
def get_Gcorr(infile):
    corrections = []
    if not os.path.exists(infile):
        return None

    with open(infile) as gfile:
        for line in gfile:
            if "Thermal correction to Gibbs Free Energy=" in line:
                ll = line.split()
                corrections.append(float(ll[-1]))

    return corrections[-1] if corrections else None


# =========================================
# Process input.log to get total Gibbs free energy (E + Gcorr)
# =========================================
def process_input_log(folder_path, final_ener_file="final.ener"):
    log_file_path = os.path.join(folder_path, "input.log")
    if os.path.exists(log_file_path):
        e_scf = get_energy(log_file_path, final_ener_file)
        g_corr = get_Gcorr(log_file_path)
        if e_scf is not None and g_corr is not None:
            G_total = e_scf + g_corr
            return G_total
    return None


# =========================================
# Process corresponding folder in "4"
# =========================================
def process_folder_4(base_path, folder_name, final_ener_file="final.ener"):
    folder_4_path = os.path.join(base_path, "4")
    parts = folder_name.split('_')
    folder_4_subfolder = '_'.join(parts[:4])  # first four parts
    folder_path = os.path.join(folder_4_path, folder_4_subfolder)
    return process_input_log(folder_path, final_ener_file)


# =========================================
# Process corresponding folder in "2" (normal + reversed)
# =========================================
def process_folder_2(base_path, folder_name, final_ener_file="final.ener"):
    folder_2_path = os.path.join(base_path, "2")
    parts = folder_name.split('_')
    folder_2_subfolder = '_'.join(parts[-2:])  # last two parts

    # Try normal order
    folder_path = os.path.join(folder_2_path, folder_2_subfolder)
    if os.path.exists(folder_path):
        return process_input_log(folder_path, final_ener_file)

    # Try reversed order if not found
    parts[-2], parts[-1] = parts[-1], parts[-2]
    reversed_folder_2 = '_'.join(parts[-2:])
    reversed_folder_path = os.path.join(folder_2_path, reversed_folder_2)
    if os.path.exists(reversed_folder_path):
        return process_input_log(reversed_folder_path, final_ener_file)

    return None


# =========================================
# Process TS folders and compute ΔG (kcal/mol)
# =========================================
def process_TS(base_path, results, final_ener_file="final.ener"):
    ts_path = os.path.join(base_path, "TS")
    folders = [f for f in os.listdir(ts_path) if os.path.isdir(os.path.join(ts_path, f))]

    for folder_to_process in folders:
        G_TS = process_input_log(os.path.join(ts_path, folder_to_process), final_ener_file)
        G_4 = process_folder_4(base_path, folder_to_process, final_ener_file)
        G_2 = process_folder_2(base_path, folder_to_process, final_ener_file)

        if G_TS is not None and G_4 is not None and G_2 is not None:
            delta_G = (G_TS - G_4 - G_2) * 627.51
            print(f"✅ ΔG (TS - 4 - 2) for {folder_to_process}: {delta_G:.2f} kcal/mol")

            parts = folder_to_process.split('_')
            dienophile = '_'.join(parts[-2:])
            diene = '_'.join(parts[:4])

            existing = next((row for row in results if row[0] == dienophile and row[1] == diene), None)
            if existing:
                existing[2] = delta_G
            else:
                results.append([dienophile, diene, delta_G])
        else:
            print(f"⚠️ Skipped {folder_to_process}: missing data.")


# =========================================
# Write results to CSV file
# =========================================
def write_results_to_csv(results, output_file='results.csv'):
    with open(output_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['dienophile', 'diene', 'Delta G (kcal/mol)'])
        writer.writerows(results)
    print(f"\n📁 Results saved to {output_file}")


# =========================================
# Main entry point
# =========================================
def main(base_path):
    results = []
    process_TS(base_path, results)
    write_results_to_csv(results)


# =========================================
# Run the script
# =========================================
if __name__ == "__main__":
    base_path = "./"   # base folder where 2/, 4/, TS/, and final.ener exist
    main(base_path)

