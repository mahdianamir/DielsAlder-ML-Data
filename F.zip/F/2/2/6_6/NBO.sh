#!/bin/bash -l
#SBATCH --time=00:09:29
#SBATCH --partition=medium
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=8
#SBATCH --mem-per-cpu=1G
#SBATCH --account=project_2002880
#SBATCH --job-name=benchmarking
#SBATCH -o ocp2k.%j
#SBATCH -e ecp2k.%j

module purge
module load gaussian/G16RevC.02

# Execute G16
srun g16 NBO.com

rm Gau*




