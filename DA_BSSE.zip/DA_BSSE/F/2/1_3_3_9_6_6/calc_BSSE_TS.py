import re

def read_gaussian_log(fname):
    """Extract total (supermolecule) SCF, CP-corrected, and BSSE energies."""
    scf_total = None
    cp_corr_energy = None
    bsse_energy = None

    with open(fname) as f:
        for line in f:
            if "SCF Done" in line and "E(RM062X)" in line:
                # انرژی کل سیستم (اولین -600ish)
                val = float(re.findall(r"[-]?\d+\.\d+", line)[0])
                if val < -600:  # یعنی supermolecule است
                    scf_total = val
            elif "Counterpoise corrected energy" in line:
                cp_corr_energy = float(re.findall(r"[-]?\d+\.\d+", line)[0])
            elif "BSSE energy" in line:
                bsse_energy = float(re.findall(r"[-]?\d+\.\d+", line)[0])
    return scf_total, cp_corr_energy, bsse_energy


def hartree_to_kcal(x):
    return x * 627.5095


# --- read SCF from def2TZVP log ---
with open("input.log") as f:
    for line in f:
        if "SCF Done" in line:
            E_ts_tzvp = float(re.findall(r"[-]?\d+\.\d+", line)[0])

E_bsse, E_cp_corr, BSSE_energy = read_gaussian_log("input_BSSE.log")

delta_E_cp = (E_cp_corr - E_bsse) if (E_cp_corr and E_bsse) else 0.0

print("\n=== BSSE Correction Report ===")
print(f"SCF (TZVP+SMD):              {E_ts_tzvp:.6f} hartree")
print(f"SCF (6-31G(d), supermol.):   {E_bsse:.6f} hartree")
print(f"CP-corrected energy:          {E_cp_corr:.6f} hartree")
print(f"BSSE energy:                  {BSSE_energy:.6f} hartree ({hartree_to_kcal(BSSE_energy):.2f} kcal/mol)")
print(f"ΔE_CP (difference):           {hartree_to_kcal(delta_E_cp):.2f} kcal/mol")

