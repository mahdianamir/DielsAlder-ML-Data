import os
import re
import csv

def read_gaussian_log(fname):
    """Extract SCF, CP-corrected, and BSSE energies from a Gaussian log file."""
    scf_total = None
    cp_corr_energy = None
    bsse_energy = None

    with open(fname) as f:
        for line in f:
            if "SCF Done" in line and "E(RM062X)" in line:
                val = float(re.findall(r"[-]?\d+\.\d+", line)[0])
                # انرژی کل سیستم، معمولا حدود -600
                if val < -100:  
                    scf_total = val
            elif "Counterpoise corrected energy" in line:
                cp_corr_energy = float(re.findall(r"[-]?\d+\.\d+", line)[0])
            elif "BSSE energy" in line:
                bsse_energy = float(re.findall(r"[-]?\d+\.\d+", line)[0])
    return scf_total, cp_corr_energy, bsse_energy

def hartree_to_kcal(x):
    return x * 627.5095

# === مسیر ریشه (همون جایی که زیرپوشه‌ها هستن)
root_dir = "."

# === ایجاد فایل CSV خروجی
output_file = "BSSE_results.csv"
with open(output_file, "w", newline="") as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["Folder", "BSSE (kcal/mol)"])

    for subdir, dirs, files in os.walk(root_dir):
        if "input.log" in files and "input_BSSE.log" in files:
            ts_name = os.path.basename(subdir)
            try:
                # خواندن انرژی‌ها
                with open(os.path.join(subdir, "input.log")) as f:
                    for line in f:
                        if "SCF Done" in line:
                            E_ts_tzvp = float(re.findall(r"[-]?\d+\.\d+", line)[0])
                            break

                E_bsse, E_cp_corr, BSSE_energy = read_gaussian_log(os.path.join(subdir, "input_BSSE.log"))

                if BSSE_energy is not None:
                    kcal = hartree_to_kcal(BSSE_energy)
                    writer.writerow([ts_name, f"{kcal:.2f}"])
                    print(f"{ts_name:<25}  BSSE = {kcal:.2f} kcal/mol")
                else:
                    writer.writerow([ts_name, "N/A"])
                    print(f"{ts_name:<25}  BSSE = N/A")

            except Exception as e:
                print(f"⚠️ Error in {ts_name}: {e}")
                writer.writerow([ts_name, "Error"])

print(f"\n✅ BSSE summary saved to '{output_file}'")

